package lesson11.figurs;

public class Main2 {
    public static void main(String[] args) {
        Oval oval = new Oval(2,5);
        Pramougolnik pramougolnik = new Pramougolnik(2,4);
        Kvadrat kvadrat = new Kvadrat(3);
        Krug krug = new Krug(5);
        Treuholnik treuholnik = new Treuholnik(3,6,9);
    }
}
