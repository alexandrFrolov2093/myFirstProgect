package lesson11.figurs;

public interface IFigur {
    double ploshad();
    double perimetr();
    void print();
}
