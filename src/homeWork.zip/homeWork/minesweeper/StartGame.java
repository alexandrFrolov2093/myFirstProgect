package homeWork.minesweeper;

public class StartGame {
    public static void main(String[] args) {
        char[][] mine = {{'*', '.', '.', '.'}, {'.', '.', '.', '.'}, {'.', '*', '.', '.'}, {'.', '.', '.', '.'}};
        char[][] xxx = {{'X', 'X', 'X', 'X'}, {'X', 'X', 'X', 'X'}, {'X', 'X', 'X', 'X'}, {'X', 'X', 'X', 'X'}};
        UtilsGame.print(mine);
        UtilsGame.print(UtilsGame.getAnswerGrid(mine));
        UtilsGame.print(xxx);
        UtilsGame.game(mine, xxx);
    }
}
